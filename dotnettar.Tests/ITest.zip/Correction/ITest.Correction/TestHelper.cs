﻿using System;
using System.Collections.Generic;
using System.Reflection;

namespace ITest.Runner
{
    public class TestHelper
    {

        public static List<TestInfo> GetTestClasses(Assembly assembly, List<TestInfo> lesClasses)
        {
            int cpt = 0;
            foreach (Type type in assembly.GetTypes())
            {
                cpt++;
                foreach (Attribute item in type.GetCustomAttributes())
                {
                    if (item.GetType().FullName.Contains("TestCase"))
                    {
                        TestInfo testCase = new TestInfo("TestCase : " + item.GetType().FullName + " " + type.FullName + " [" + cpt + "] ", cpt);
                        lesClasses.Add(testCase);
                    }
                    else
                    //c'est pas clean je vais y remédier à l'occasion
                    if (item.GetType().FullName.Contains("Test") ||
                        item.GetType().FullName.Contains("TearDown") ||
                        item.GetType().FullName.Contains("Explicit") ||
                        item.GetType().FullName.Contains("TearDown"))
                    {

                        //lesTests.Add(cpt);
                        TestInfo testInfo = new TestInfo("Classes présentes dans l'assemblage : " + item.GetType().FullName + " " + type.FullName + " [" + cpt + "] ", cpt);
                        lesClasses.Add(testInfo);
                    }
                }

            }
            return lesClasses;
        }


        public static List<string> GetTestMethods(Assembly assembly, int choix, List<string> lesMethodes)
        {
            foreach (MethodInfo attribute in assembly.GetTypes()[choix].GetMethods())
            {
                foreach (Attribute item in attribute.GetCustomAttributes())
                {
                    if (item.GetType().FullName.Contains("TestCase"))
                    {
                        lesMethodes.Add("Méthodes présentes dans l'assemblage : " + item.GetType().FullName + " " + attribute);
                    }
                    else
                    //c'est pas clean je vais y remédier à l'occasion
                    if (item.GetType().FullName.Contains("Test") ||
                        item.GetType().FullName.Contains("TearDown") ||
                        item.GetType().FullName.Contains("Explicit") ||
                        item.GetType().FullName.Contains("TearDown"))
                    {
                        lesMethodes.Add("Méthodes présentes dans l'assemblage : " + item.GetType().FullName + " " + attribute);
                        //Console.WriteLine("Méthodes présentes dans l'assemblage : " + item.GetType().FullName.ToString() + " " + attribute.ToString());
                    }
                }
            }
            return lesMethodes;
        }

        public static List<Results> RunTestMethods(Assembly assembly, int choix, List<Results> lesResultats)
        {

            Type type = assembly.GetTypes()[choix];
            foreach (MethodInfo attribute in type.GetMethods())
            {
                foreach (Attribute item in attribute.GetCustomAttributes())
                {
                    if (item.GetType().FullName.Contains("Test"))
                    {
                        DateTime start = DateTime.Now;
                        try
                        {

                            attribute.Invoke(Activator.CreateInstance(type), null);
                            TimeSpan dur = DateTime.Now - start;
                            Results result = new Results(attribute.ToString(), "pass", dur.ToString(), "Méthodes éxécutées dans l'assemblage : " + item.GetType().FullName + " " + attribute);
                            lesResultats.Add(result);
                        }
                        catch (Exception e)
                        {
                            TimeSpan dur = DateTime.Now - start;
                            Results result = new Results(attribute.ToString(), "fail", dur.ToString(), "Test échoué dans l'assemblage : " + item.GetType().FullName + " " + e);
                            lesResultats.Add(result);
                        }

                    }
                }
            }
            return lesResultats;
        }

        public static List<Results> RunTestCases(Assembly assembly, int choix, List<Results> lesResultats)
        {
            Type type = assembly.GetTypes()[choix];
            foreach (MethodInfo attribute in type.GetMethods())
            {
                foreach (Attribute item in attribute.GetCustomAttributes())
                {
                    if (item.GetType().FullName.Contains("Test"))
                    {
                        DateTime start = DateTime.Now;
                        try
                        {
                            attribute.Invoke(Activator.CreateInstance(type), null);
                            TimeSpan dur = DateTime.Now - start;
                            Results result = new Results(attribute.ToString(), "pass", dur.ToString(), "Méthodes éxécutées dans l'assemblage : " + item.GetType().FullName + " " + attribute);
                            lesResultats.Add(result);
                        }
                        catch (Exception e)
                        {
                            TimeSpan dur = DateTime.Now - start;
                            Results result = new Results(attribute.ToString(), "fail", dur.ToString(), "Test échoué dans l'assemblage : " + item.GetType().FullName + " " + e.Message);
                            lesResultats.Add(result);
                        }

                    }
                }
            }
            return lesResultats;
        }


    }
}
