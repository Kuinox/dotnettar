﻿using CommandLine;

namespace ITest.Runner
{
    class Options
    {
        [Option('b', "bin", Required = true, HelpText = "Path of the binary to test")]
        public string Path { get; set; }

        [Option('o', "output", Required = false, HelpText = "Path of the result of the test", Default = "output.xml")]
        public string OutputPath { get; set; }



    }
}
