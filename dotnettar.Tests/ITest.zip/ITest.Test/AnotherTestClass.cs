﻿using FluentAssertions;
using ITest.framework;

namespace ITest.Test
{
    [TestFixture]
    public class AnotherTestClass
    {

        [Test]
        public void Add()
        {
            MyMath maths = new MyMath();
            //Assert.AreEqual(31, maths.Add(20, 11));
            maths.Add(20, 11).Should().Be(31);

        }

        [Test]
        public void Sub()
        {
            MyMath maths = new MyMath();
            //Assert.AreEqual(10, maths.Sub(20, 10));
            maths.Sub(20, 10).Should().Be(10);
        }

        [Test]
        public void FailSub()
        {
            MyMath maths = new MyMath();
            //Assert.AreEqual(10, maths.Sub(20, 10));
            maths.Sub(20, 10).Should().Be(15);
        }

        public void Div()
        {
            MyMath maths = new MyMath();
            //Assert.AreEqual(5, maths.Mult(10, 2));
            maths.Div(10, 2).Should().Be(5);
        }
        [Test]
        public void Mult()
        {
            MyMath maths = new MyMath();
            //Assert.AreEqual(10, maths.Mult(2, 5));
            maths.Mult(2, 5).Should().Be(10);
        }
    }
}
