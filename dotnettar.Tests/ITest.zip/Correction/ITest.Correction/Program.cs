﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Xml;
using System.IO;
using CommandLine;

/* *
 * 
 * Status : WIP /!\
 * Testing the loading of the DLL
 *
 * */
namespace ITest.Runner
{
    class Program
    {
        static void Main(string[] args)
        {
            Parser.Default.ParseArguments<Options>(args)
                .WithParsed(RunOptionsAndReturnExitCode)
                .WithNotParsed(HandleParseError);
        }

        static void RunOptionsAndReturnExitCode(Options options)
        {
            //=======================================================
            List<TestInfo> lesClasses = new List<TestInfo>();
            List<string> lesMethodes = new List<string>();
            List<Results> lesResultats = new List<Results>();
            List<int> lesChoix = new List<int>();
            Assembly assembly = Assembly.LoadFrom(options.Path);
            //=======================================================

            FileStream myFileStream = new FileStream(options.OutputPath, FileMode.OpenOrCreate);
            XmlTextWriter myXmlTextWriter = new XmlTextWriter(myFileStream, System.Text.Encoding.UTF8);
            myXmlTextWriter.WriteStartDocument(false);
            myXmlTextWriter.WriteStartElement("itest");
            myXmlTextWriter.WriteElementString("title", null, "ITest.framework runner");
            myXmlTextWriter.WriteElementString("assembly-name", null, assembly.FullName);
            Console.WriteLine(assembly.FullName);
            Console.WriteLine("Retrieving Classes From DLL...");
            // récupération du nom des classes
            lesClasses = TestHelper.GetTestClasses(assembly, lesClasses);
            myXmlTextWriter.WriteStartElement("assembly");
            foreach (TestInfo testinfo in lesClasses)
            {
                // affichage et enregistrement de la position des classes dans l'assembly
                myXmlTextWriter.WriteElementString("classe", null, testinfo.Info);
                Console.WriteLine(testinfo.Info);
                lesChoix.Add(testinfo.Cpt);

            }
            myXmlTextWriter.WriteEndElement();

            Console.WriteLine("Retrieving Classes From DLL...OK");
            if (lesClasses.Equals(null))
            {
                Console.WriteLine("Il n'ya pas de Classe dans l'assembly");
                return;
            }

            Console.WriteLine("Exploration des classes");

            foreach (int classe in lesChoix)
            {
                myXmlTextWriter.WriteStartElement("methods");
                var choix = classe - 1;
                Console.WriteLine("Displaying Methods From Classes...");
                lesMethodes = TestHelper.GetTestMethods(assembly, choix, lesMethodes);
                foreach (string item in lesMethodes)
                {
                    myXmlTextWriter.WriteElementString("method", null, item);
                    Console.WriteLine(item);
                }

                Console.WriteLine("Displaying Methods From Classes...OK");
                Console.WriteLine("Executing Test methods...");
                myXmlTextWriter.WriteEndElement();
                myXmlTextWriter.WriteStartElement("results");
                lesResultats = TestHelper.RunTestMethods(assembly, choix, lesResultats);
                foreach (Results result in lesResultats)
                {
                    myXmlTextWriter.WriteStartElement("result");
                    myXmlTextWriter.WriteElementString("name", null, result.Name);
                    myXmlTextWriter.WriteElementString("state", null, result.State);
                    myXmlTextWriter.WriteElementString("time", null, result.Time);
                    myXmlTextWriter.WriteElementString("details", null, "Resutat : " + result.Detail);
                    myXmlTextWriter.WriteEndElement();
                    Console.WriteLine("Resutat : " + result.State);
                }

                Console.WriteLine("Executing Test Methods...OK");
                myXmlTextWriter.WriteEndElement();
                lesMethodes.Clear();
                lesResultats.Clear();
            }

            myXmlTextWriter.Flush();
            myXmlTextWriter.Close();
        }

        static void HandleParseError(IEnumerable<Error> errors)
        {
            foreach (var error in errors)
            {
                Console.WriteLine(Enum.GetName(typeof(ErrorType), error.Tag));
            }
        }
    }
}
