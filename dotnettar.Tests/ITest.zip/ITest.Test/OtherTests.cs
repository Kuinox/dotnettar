﻿using FluentAssertions;
using ITest.framework;

namespace ITest.Test
{
    [TestFixture]
    class OtherTests
    {
        [Explicit]
        public void Add()
        {
            MyMath maths = new MyMath();
            //Assert.AreEqual(31, maths.Add(20, 11));
            maths.Add(20, 11).Should().Be(31);

        }

        [TearDown]
        public void Sub()
        {
            MyMath maths = new MyMath();
            //Assert.AreEqual(10, maths.Sub(20, 10));
            maths.Sub(20, 10).Should().Be(10);
        }

        [Setup]
        public void Div()
        {
            MyMath maths = new MyMath();
            //Assert.AreEqual(5, maths.Sub(10, 2));
            maths.Div(10, 2).Should().Be(5);
        }


        [TestCase(12, 3)]
        public void DivCase (int a, int b)
        {
            MyMath maths = new MyMath();
            //Assert.AreEqual(a/b, maths.Sub(a, b));
            maths.Div(a, b).Should().Be(a/b);
        }


        //[Test]

        //public void DownloadContentAsync_ValidHttpAddress_ReturnsData()

        //{

        //    // setup

        //    var task = new Task<String>(

        //        () => { return "test string"; });

        //    task.Start();
        //    Task.Delay(100);
        //}
    }
}
