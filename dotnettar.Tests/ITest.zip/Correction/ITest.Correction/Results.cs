﻿namespace ITest.Runner
{
    public class Results:object
    {
        public Results(string name,string state, string time, string detail)
        {
            Name = name;
            State = state;
            Time = time;
            Detail = detail;
        }

        public string Name { get; set; }
        public string State { get; set; }
        public string Time { get; set; }
        public string Detail { get; set; }
    }
}
