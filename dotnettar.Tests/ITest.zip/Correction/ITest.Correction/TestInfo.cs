﻿namespace ITest.Runner
{
    public class TestInfo:object
    {
        public  TestInfo (string info,int cpt)
        {
            Cpt = cpt;
            Info = info;
        }

        public string Info { get; set; }
        public int Cpt { get; set; }
    }
}
